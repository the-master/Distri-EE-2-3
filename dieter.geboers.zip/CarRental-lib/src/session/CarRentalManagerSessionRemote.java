
package session;

import java.util.Collection;
import javax.ejb.Remote;
import rental.CarType;

@Remote
public interface CarRentalManagerSessionRemote {
    
    public Collection<CarType> getCarTypes(String rentalCompany);
    public int getNbOfReservations(String rentalCompany, String cartype);
    public String getBestCustomer();
    
}
