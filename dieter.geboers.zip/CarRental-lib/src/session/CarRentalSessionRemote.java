package session;

import java.util.Date;
import java.util.List;
import java.util.Set;
import javax.ejb.Remote;
import rental.Quote;
import rental.Reservation;
import rental.ReservationException;

@Remote
public interface CarRentalSessionRemote {
    Set<String> getAllRentalCompanies();
    public Quote createQuote(Date start, Date end, String carType, String region, String name) throws ReservationException;
    public List<Quote> getCurrentQuotes();
    public List<Reservation> confirmQuotes() throws ReservationException;
    public List<String> getAvailableCarTypes(Date start, Date end);
}
