package client;

import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.naming.InitialContext;
import rental.Reservation;
import rental.ReservationConstraints;
import session.CarRentalManagerSessionRemote;
import session.CarRentalSessionRemote;
/**
 *Some notes:
 * The owner of the CarRentalSession is not checked when creating new quotes.
  */
public class Main extends AbstractTestAgency<CarRentalSessionRemote, CarRentalManagerSessionRemote>{
    
    @EJB
    static CarRentalSessionRemote session;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("found rental companieswoop: "+session.getAllRentalCompanies());
        try {
            new Main("simpleTrips").run();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public Main(String scriptFile) {
        super(scriptFile);
    }

    @Override
    protected CarRentalSessionRemote getNewReservationSession(String name) throws Exception {
//        return session;
        InitialContext initialContext = new InitialContext();
        return (CarRentalSessionRemote) initialContext.lookup(CarRentalSessionRemote.class.getName());
     }

    @Override
    protected CarRentalManagerSessionRemote getNewManagerSession(String name, String carRentalName) throws Exception {
        return (CarRentalManagerSessionRemote)new InitialContext().lookup(CarRentalManagerSessionRemote.class.getName());
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void checkForAvailableCarTypes(CarRentalSessionRemote session, Date start, Date end) throws Exception {
        System.out.println(session.getAvailableCarTypes(start, end));
    }

    @Override
    protected void addQuoteToSession(CarRentalSessionRemote session, String name, Date start, Date end, String carType, String region) throws Exception {
        session.createQuote(start, end, carType, region, name);
    }

    @Override
    protected List<Reservation> confirmQuotes(CarRentalSessionRemote session, String name) throws Exception {
        return session.confirmQuotes();
    }

    @Override
    protected int getNumberOfReservationsForCarType(CarRentalManagerSessionRemote ms, String carRentalName, String carType) throws Exception {
        return ms.getNbOfReservations(carRentalName,carType);
    }
}
