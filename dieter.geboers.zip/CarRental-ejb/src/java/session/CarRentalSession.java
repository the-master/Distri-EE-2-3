package session;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.ejb.Stateful;
import rental.CarRentalCompany;
import rental.CarType;
import rental.Quote;
import rental.RentalStore;
import rental.Reservation;
import rental.ReservationConstraints;
import rental.ReservationException;

@Stateful
public class CarRentalSession implements CarRentalSessionRemote {
    
    private List<Quote> quotes = new ArrayList<Quote>();


    @Override
    public Set<String> getAllRentalCompanies() {
        return new HashSet<String>(RentalStore.getRentals().keySet());
    }

    @Override
    public Quote createQuote(Date start, Date end, String carType, String region, String name) throws ReservationException {
        for (CarRentalCompany company : RentalStore.getRentals().values()) {
            try {
                Quote q = company.createQuote(new ReservationConstraints(start, end, carType, region), name);
                quotes.add(q);
                return q;
            } catch (ReservationException e) {
                
            }
        }
        throw new ReservationException(name);
    }
    
    /**
     *
     * @return
     */
    @Override
    public List<Quote> getCurrentQuotes() {
        return new ArrayList<Quote>(quotes);
    }
    
    @Override
    public List<Reservation> confirmQuotes() throws ReservationException {
        ArrayList<Reservation> reservations = new ArrayList<Reservation>();
        for(Quote quote : quotes) {
            try {
                reservations.add(RentalStore.getRental(quote.getRentalCompany()).confirmQuote(quote));
            } catch (ReservationException e) {
                cancelReservations(reservations);
                throw e;
            }
        }
        return reservations;
    }
    
    private void cancelReservations(List<Reservation> reservations) {
        for (Reservation reservation : reservations) {
            RentalStore.getRental(reservation.getRentalCompany()).cancelReservation(reservation);
        }
    }

    @Override
    public List<String> getAvailableCarTypes(Date start, Date end) {
        Set<String> resultSet = new HashSet<String>();
        for (CarRentalCompany company : RentalStore.getRentals().values())
            for (CarType carType : company.getAvailableCarTypes(start, end))
            {
                resultSet.add(carType.getName());
            }
        return new ArrayList<String>(resultSet);
    }
    
}
