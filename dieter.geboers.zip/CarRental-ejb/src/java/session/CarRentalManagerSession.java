
package session;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import rental.Car;
import rental.CarRentalCompany;
import rental.CarType;
import rental.RentalStore;
import rental.Reservation;

@Stateless
//@LocalBean
public class CarRentalManagerSession implements CarRentalManagerSessionRemote {

    @Override
    public Collection<CarType> getCarTypes(String rentalCompany) {
        return RentalStore.getRental(rentalCompany).getAllCarTypes();
    }

    @Override
    public int getNbOfReservations(String rentalCompany, String cartype) {
        int reservations=0;
        for(Car car:RentalStore.getRental(rentalCompany).getCars())
            if(car.getType().getName().equals(cartype))
                reservations+=car.getAllReservations().size();
        return reservations;
                
    }

    @Override
    public String getBestCustomer() {
        Map<String,Integer> customers=new HashMap<String, Integer>();
       
        for(CarRentalCompany comp:RentalStore.getRentals().values())
            for(Car car:comp.getCars())
                for(Reservation reservation:car.getAllReservations())
                {
                    if(!customers.containsKey(reservation.getCarRenter()))
                        customers.put(reservation.getCarRenter(), 0);
                    customers.put(reservation.getCarRenter(), customers.get(reservation.getCarRenter()+1));
                }
            
        int best=0;
        String cust=null;
        for(Entry<String,Integer> e:customers.entrySet())
            if(e.getValue()>best)
                cust=e.getKey();
        return cust;
    }

}
